
<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>
    <cart-component></cart-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Caliburger_QR\resources\views/cart/show.blade.php ENDPATH**/ ?>