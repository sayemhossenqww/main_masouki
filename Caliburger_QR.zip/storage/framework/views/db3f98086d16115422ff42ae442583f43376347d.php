<title><?php echo $__env->yieldContent('title', config('app.meta_title')); ?></title>
<meta name="keywords" content="<?php echo $__env->yieldContent('keywords', config('app.keywords')); ?>">
<meta name="description" content="<?php echo $__env->yieldContent('description', config('app.meta_description')); ?>">
<meta property="fb:app_id" content="<?php echo e(config('app.fb_app_id')); ?>" />
<meta type="metaTags" name="application-name" content="<?php echo e(config('app.name')); ?>" />
<meta type="metaTags" name="mobile-web-app-capable" content="yes" />
<?php /**PATH C:\Users\Administrator\Desktop\Caliburger&QR\resources\views/seotools/metatags.blade.php ENDPATH**/ ?>