
<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('page_name', 'Categories'); ?>

<?php $__env->startSection('content'); ?>

<category-component></category-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Caliburger_QR\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>