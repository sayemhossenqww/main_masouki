
<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('page_name', 'Services'); ?>

<?php $__env->startSection('content'); ?>
    <service-component usd-rate-value="<?php echo e($usdRate); ?>"></service-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Caliburger_QR\resources\views/admin/services/show.blade.php ENDPATH**/ ?>