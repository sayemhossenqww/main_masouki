<span class=" font-cinzel fw-bold"><?php echo e(config('app.name')); ?></span> © <?php echo e(date('Y')); ?> Copyright:
<a class="link-primary" href="https://wmktech.com/" target="_blank">WMKTECH</a>
<?php /**PATH C:\Users\Administrator\Desktop\Caliburger&QR\resources\views/layouts/copyright.blade.php ENDPATH**/ ?>