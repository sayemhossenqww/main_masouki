
<meta name="twitter:description" content="<?php echo $__env->yieldContent('description', config('app.meta_description')); ?>" />
<meta name="twitter:title" content="<?php echo $__env->yieldContent('title', config('app.meta_title')); ?>" />
<meta name="twitter:image" content="<?php echo $__env->yieldContent('og_image', asset('share.png')); ?>" />
<meta name="twitter:site" content="{{ config('app.twitter_username') }}" />
<meta name="twitter:creator" content="<?php echo e(config('app.domain')); ?>" />
<meta name="twitter:image:alt" content="<?php echo $__env->yieldContent('title', config('app.name')); ?>" />
<?php /**PATH C:\Users\Administrator\Desktop\Caliburger&QR\resources\views/seotools/twitter.blade.php ENDPATH**/ ?>