<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "website",
        "name": "<?php echo e(config('app.meta_title')); ?>"
    }
</script>
<?php /**PATH C:\Users\Administrator\Desktop\Caliburger&QR\resources\views/seotools/json-ld.blade.php ENDPATH**/ ?>