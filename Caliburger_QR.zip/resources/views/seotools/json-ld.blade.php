<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "website",
        "name": "{{ config('app.meta_title') }}"
    }
</script>
