@extends('errors.master')
@section('title', '500 Internal Server Error!')
@section('content')
    <h1>500</h1>
    <h3>Internal Server Error!</h3>
    <div>The server encountered an unexpected condition that prevents it from fulfilling the request.</div>
    <div>Our developers have received a notification about the issue and everything will be fixed soon.</div>
@endsection
