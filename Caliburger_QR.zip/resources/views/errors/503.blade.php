@extends('errors.master')
@section('title', '503 Maintenance')
@section('content')
    <h1>503</h1>
    <h3>Maintenance.</h3>
    <p>We Will Be Back Soon</p>
@endsection
