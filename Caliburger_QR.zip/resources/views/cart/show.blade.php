@extends('layouts.app')
@section('title', 'Cart')

@section('content')
    <cart-component></cart-component>
@endsection
