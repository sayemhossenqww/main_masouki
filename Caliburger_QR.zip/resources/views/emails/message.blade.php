@component('mail::message')
{!! $data->message !!}
@endcomponent
