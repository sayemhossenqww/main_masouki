@extends('admin.layouts.app')
@section('title', 'Banners')
@section('page_name', 'Banners')

@section('content')
    <banner-component></banner-component>
@endsection
