@extends('admin.layouts.app')
@section('title', 'Coupons')
@section('page_name', 'Coupons')

@section('content')

<coupon-component></coupon-component>
@endsection
