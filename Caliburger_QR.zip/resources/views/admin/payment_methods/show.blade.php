@extends('admin.layouts.app')
@section('title', 'Payment Methods')
@section('page_name', 'Payment Methods')

@section('content')
<payment-method-component></payment-method-component>
@endsection
