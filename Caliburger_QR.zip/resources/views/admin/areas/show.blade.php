@extends('admin.layouts.app')
@section('title', 'Delivery Areas')
@section('page_name', 'Delivery Areas')

@section('content')

<area-component></area-component>
@endsection
