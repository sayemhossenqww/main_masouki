<div class="card shadow-sm mb-3">
    <div class="card-body">
        <h5 class="card-title">Change Password</h5>
        <h6 class="card-subtitle mb-2 text-muted">Make sure your account is using a long, random password to stay secure.</h6>
        <update-password-component></update-password-component>
    </div>
</div>
