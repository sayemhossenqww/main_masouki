@extends('admin.layouts.app')
@section('title', 'Categories')
@section('page_name', 'Categories')

@section('content')

<category-component></category-component>
@endsection
