<span class=" font-cinzel fw-bold">{{ config('app.name') }}</span> © {{ date('Y') }} Copyright:
<a class="link-primary" href="https://wmktech.com/" target="_blank">WMKTECH</a>
