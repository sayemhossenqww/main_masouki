@if ($global_alert)
    <div class="alert alert-info alert-dismissible fade show shadow-sm rounded-1 mb-3" role="alert">
        {!! $global_alert !!}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif
