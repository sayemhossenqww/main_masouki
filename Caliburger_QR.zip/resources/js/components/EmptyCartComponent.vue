<template>
  <div class="text-center py-5">
    <img
      src="/images/webp/paper-bag.webp"
      class="mb-3"
      height="180"
      alt="cart"
    />
    <div class="h2 mb-2">Your bag is empty.</div>
    <div class="h2 mb-3">
      Add your preferred items and come back here to complete your order.
    </div>
    <a href="/" class="btn btn-outline-dark px-4">
      <mt-icon icon="west" style="me-2"></mt-icon> Back to menu
    </a>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>
